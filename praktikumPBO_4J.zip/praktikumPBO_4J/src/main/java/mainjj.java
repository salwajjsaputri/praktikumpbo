// File: Main.java
public class mainjj {
    public static void main(String[] args) {
        mobiljj mobil = new mobiljj();
        mobil.nama = "Toyota";
        mobil.kecepatan = 180;
        mobil.jumlahPintu = 4;
        mobil.tampilkanInfo();

        sepedamotorj motor = new sepedamotorj();
        motor.nama = "Yamaha";
        motor.kecepatan = 120;
        motor.jenisMesin = "2-tak";
        motor.tampilkanInfo();
    }
}