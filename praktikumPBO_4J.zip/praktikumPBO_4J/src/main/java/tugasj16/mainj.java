/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugasj16;

/**
 *
 * @author acer
 */
// Kelas Utama untuk Menjalankan Program
class mainjj {
    public static void main(String[] args) {
        Kucing kucing = new Kucing();
        kucing.nama = "Mimi";
        kucing.jenis = "Mamalia";
        kucing.tampilkanInfo();

        System.out.println();

        Anjing anjing = new Anjing();
        anjing.nama = "Milo";
        anjing.jenis = "Mamalia";
        anjing.tampilkanInfo();
    }
}
