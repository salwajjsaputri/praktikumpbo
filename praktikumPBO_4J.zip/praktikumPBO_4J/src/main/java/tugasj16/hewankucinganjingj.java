package tugasj16;
// Kelas Induk Hewan
class Hewan {
    String nama;
    String jenis;

    void tampilkanInfo() {
        System.out.println("Nama Hewan: " + nama);
        System.out.println("Jenis: " + jenis);
    }
}

// Kelas Turunan Kucing
class Kucing extends Hewan {
    String suara = "Meong";

    @Override
    void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Suara: " + suara);
    }
}

// Kelas Turunan Anjing
class Anjing extends Hewan {
    String suara = "Guk Guk";

    @Override
    void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Suara: " + suara);
    }
}
