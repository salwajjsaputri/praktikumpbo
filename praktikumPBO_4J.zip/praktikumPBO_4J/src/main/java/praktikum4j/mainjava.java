package praktikum4j;

public class mainjava {
    public static void main(String[] args) {
        System.out.println("=".repeat(50));
        System.out.println("PROGRAM DATA PEKERJA");
        System.out.println("=".repeat(50));
        
        // 1. Membuat objek Pekerja
        pekerjajava pekerja1 = new pekerjajava("Salwa JJ Saputri", 20, "Software Engineer", 8500000);
        
        // 2. Menampilkan informasi pekerja dengan toString()
        System.out.println("\n" + pekerja1.toString());
        
        // 3. Mengubah nama menggunakan setter
        System.out.println("\n" + "=".repeat(50));
        System.out.println("MENGUBAH DATA PEKERJA");
        System.out.println("=".repeat(50));
        
        pekerja1.setNama("Atha Zaki Anjabi");
        pekerja1.setUsia(20);
        pekerja1.setGaji(9500000);
        
        // Tampilkan setelah perubahan
        System.out.println("\n" + pekerja1.toString());
        
        // 4. Percobaan akses langsung atribut
        System.out.println("\n" + "=".repeat(50));
        System.out.println("PERCOBAAN AKSES LANGSUNG ATRIBUT");
        System.out.println("=".repeat(50));
        
        // Membuat objek baru untuk percobaan
        pekerjajava pekerja2 = new pekerjajava("Budi Santoso", 25, "Data Analyst", 7000000);
        
        System.out.println("\nMencoba mengakses atribut secara langsung:");
        
        // Percobaan 1: Akses langsung ke atribut nama (private)
        System.out.println("\n1. Akses langsung ke atribut nama (private):");
        System.out.println("   Kode: pekerja2.nama");
        System.out.println("   ❌ ERROR! Tidak bisa diakses karena private.");
        System.out.println("   Penjelasan: Atribut nama bersifat private, hanya bisa");
        System.out.println("   diakses melalui metode getter/setter di dalam kelas Manusia.");
        
        // Percobaan 2: Akses langsung ke atribut usia (protected)
        System.out.println("\n2. Akses langsung ke atribut usia (protected):");
        System.out.println("   Kode: pekerja2.usia");
        System.out.println("   ✅ Bisa diakses! Usia = " + pekerja2.usia);
        System.out.println("   Penjelasan: Atribut usia bersifat protected, sehingga");
        System.out.println("   bisa diakses oleh subclass (Pekerja) yang mewarisi Manusia.");
        
        // Percobaan 3: Akses langsung ke atribut gaji (private di Pekerja)
        System.out.println("\n3. Akses langsung ke atribut gaji (private):");
        System.out.println("   Kode: pekerja2.gaji");
        System.out.println("   ❌ ERROR! Tidak bisa diakses karena private.");
        System.out.println("   Penjelasan: Atribut gaji bersifat private, hanya bisa");
        System.out.println("   diakses melalui metode getter/setter di dalam kelas Pekerja.");
        
        // Percobaan 4: Akses langsung ke atribut pekerjaan (public)
        System.out.println("\n4. Akses langsung ke atribut pekerjaan (public):");
        System.out.println("   Kode: pekerja2.pekerjaan");
        System.out.println("   ✅ Bisa diakses! Pekerjaan = " + pekerja2.pekerjaan);
        System.out.println("   Penjelasan: Atribut pekerjaan bersifat public, sehingga");
        System.out.println("   bisa diakses dari mana saja tanpa batasan.");
        
        // Ringkasan
        System.out.println("\n" + "=".repeat(50));
        System.out.println("RINGKASAN AKSES MODIFIER");
        System.out.println("=".repeat(50));
        System.out.println("\n┌─────────────┬──────────────┬─────────────────────────┐");
        System.out.println("│  Modifier   │   Atribut    │  Status Akses Langsung  │");
        System.out.println("├─────────────┼──────────────┼─────────────────────────┤");
        System.out.println("│  private    │    nama      │  ❌ TIDAK BISA          │");
        System.out.println("│  protected  │    usia      │  ✅ BISA (dari subclass)│");
        System.out.println("│  public     │  pekerjaan   │  ✅ BISA                │");
        System.out.println("│  private    │    gaji      │  ❌ TIDAK BISA          │");
        System.out.println("└─────────────┴──────────────┴─────────────────────────┘");
    }
}