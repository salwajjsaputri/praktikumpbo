package praktikum4j;

public class pekerjajava extends Manusia {
    // Atribut tambahan dengan akses modifier private
    private double gaji;
    
    // Constructor
    public pekerjajava(String nama, int usia, String pekerjaan, double gaji) {
        super(nama, usia, pekerjaan);  // Memanggil constructor kelas induk
        this.gaji = gaji;
    }
    
    // Getter dan Setter untuk gaji
    public double getGaji() {
        return gaji;
    }
    
    public void setGaji(double gaji) {
        this.gaji = gaji;
    }
    
    // Override method toString()
    @Override
    public String toString() {
        return "=== Informasi Pekerja ===\n" +
               "Nama      : " + getNama() + "\n" +
               "Usia      : " + usia + " tahun\n" +  // usia bisa diakses langsung karena protected
               "Pekerjaan : " + pekerjaan + "\n" +   // pekerjaan bisa diakses langsung karena public
               "Gaji      : Rp " + String.format("%,.0f", gaji);
    }
}