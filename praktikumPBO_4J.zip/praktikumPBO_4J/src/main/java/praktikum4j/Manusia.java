package praktikum4j;

public class Manusia {
    // Atribut dengan akses modifier yang tepat
    private String nama;        // private - hanya bisa diakses dalam kelas ini
    protected int usia;         // protected - bisa diakses oleh subclass
    public String pekerjaan;    // public - bisa diakses dari mana saja
    
    // Constructor
    public Manusia(String nama, int usia, String pekerjaan) {
        this.nama = nama;
        this.usia = usia;
        this.pekerjaan = pekerjaan;
    }
    
    // Getter dan Setter untuk nama (private)
    public String getNama() {
        return nama;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    // Getter dan Setter untuk usia (protected)
    public int getUsia() {
        return usia;
    }
    
    public void setUsia(int usia) {
        this.usia = usia;
    }
    
    // Getter dan Setter untuk pekerjaan (public)
    public String getPekerjaan() {
        return pekerjaan;
    }
    
    public void setPekerjaan(String pekerjaan) {
        this.pekerjaan = pekerjaan;
    }
}