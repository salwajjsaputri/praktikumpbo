public class Main {
    public static void main(String[] args) {

        Produk p1 = new Elektronik("Laptop", 15000000, 2);
        Produk p2 = new Makanan("Snack", 15000, "2023-12-30");

        System.out.println("=== Output Produk ===");
        p1.tampilkanInfo();
        System.out.println();
        p2.tampilkanInfo();
        System.out.println();

        Pegawai pg1 = new PegawaiTetap("NamaKamu", 5000000, 1000000);
        Pegawai pg2 = new PegawaiKontrak("Andi", 3000000, 12);

        System.out.println("=== Output Pegawai ===");
        pg1.tampilkanInfo();
        System.out.println();
        pg2.tampilkanInfo();
    }
}