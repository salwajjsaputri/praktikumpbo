/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaJ;

/**
 *
 * @author acer
 */
public class pboJ{
    public static void main(String[] args) {
        classJ kucing = new classJ("Mimi", 3);
        kucing.suara();
        kucing.info();
    }
}