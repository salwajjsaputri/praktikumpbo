/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3;

/**
 *
 * @author acer
 */
public class MainJ {
    public static void main(String[] args) {
        hewannnJ kucing = new hewannnJ();
        kucing.nama = "Mimi";
        kucing.umur = 3;
        kucing.suara();
    }
}

