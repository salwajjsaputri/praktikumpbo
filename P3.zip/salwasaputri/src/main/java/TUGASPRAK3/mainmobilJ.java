/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGASPRAK3;

/**
 *
 * @author acer
 */
public class mainmobilJ {
 // File: Main.java
    public static void main(String[] args) {
        // Membuat dua objek dari class Mobil
        mobilJ mobil1 = new mobilJ("Toyota", "Avanza", 2020, "Hitam");
        mobilJ mobil2 = new mobilJ("Honda", "Civic", 2022, "Putih");

        // Memanggil startEngine()
        mobil1.startEngine();
        mobil2.startEngine();
        System.out.println();

        // Menampilkan informasi awal kedua objek
        System.out.println("=== Informasi Mobil 1 ===");
        mobil1.displayInfo();

        System.out.println("=== Informasi Mobil 2 ===");
        mobil2.displayInfo();

        // Mengubah warna mobil menggunakan setter
        mobil1.setWarna("Merah");
        mobil2.setWarna("Abu-abu");

        // Menampilkan informasi setelah warna diubah
        System.out.println("=== Informasi Mobil 1 (Setelah Ubah Warna) ===");
        mobil1.displayInfo();

        System.out.println("=== Informasi Mobil 2 (Setelah Ubah Warna) ===");
        mobil2.displayInfo();
    }
}   
